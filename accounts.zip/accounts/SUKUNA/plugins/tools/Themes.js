import fs from "fs";
import path from "path";
import { downloadContentFromMessage } from "@whiskeysockets/baileys";

export const NovaUltra = {
  command: "ثيم",
  description: "🎨 إنشاء ثيم جديد من صورة (للنخبة فقط).",
  elite: "on",
  group: true,
  prv: false,
  lock: "off"
};

export default {
  NovaUltra,
  async execute({ sock, msg, args }) {
    const remoteJid = msg.key.remoteJid;

    // 1. التحقق من الرد على صورة ومن وجود اسم للثيم
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const isImage = quoted?.imageMessage || quoted?.viewOnceMessageV2?.message?.imageMessage;

    if (!isImage) {
      return sock.sendMessage(remoteJid, { text: "❌ يجب الرد على *صورة* لاستخدام هذا الأمر." }, { quoted: msg });
    }

    if (!args[0]) {
      return sock.sendMessage(remoteJid, { text: "⚠️ يرجى تحديد اسم للصورة. مثال: `ثيم as`" }, { quoted: msg });
    }

    const themeImageName = args[0].replace(/[^a-zA-Z0-9-_]/g, "") + ".jpg";
    const basePath = "/sdcard/ultra-bot/accounts/SUKUNA/nova/themes/";

    try {
      // 2. التأكد من وجود المجلد الرئيسي
      if (!fs.existsSync(basePath)) fs.mkdirSync(basePath, { recursive: true });

      // 3. تحديد رقم المجلد الجديد تلقائياً
      const folders = fs.readdirSync(basePath)
        .filter(f => fs.lstatSync(path.join(basePath, f)).isDirectory() && !isNaN(f))
        .map(Number);
      
      const nextFolderNum = folders.length > 0 ? Math.max(...folders) + 1 : 1;
      const newFolderPath = path.join(basePath, nextFolderNum.toString());

      // إنشاء المجلد الجديد
      fs.mkdirSync(newFolderPath, { recursive: true });

      // 4. تحميل الصورة وحفظها
      const imageMessage = quoted.imageMessage || quoted.viewOnceMessageV2?.message?.imageMessage;
      const stream = await downloadContentFromMessage(imageMessage, "image");
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      const finalImagePath = path.join(newFolderPath, themeImageName);
      fs.writeFileSync(finalImagePath, buffer);

      // 5. إنشاء ملف الكود (art.js) بالمسارات الديناميكية
      const codeContent = `
import chalk from 'chalk';
import { execSync } from 'child_process';

// المسار تم توليده تلقائياً
const imagePath = '${finalImagePath}';

let dynamicImage = '';
try {
    // تم ضبط العرض ليتناسب مع التيرموكس والواتساب
    dynamicImage = execSync(\`~/go/bin/ascii-image-converter "\${imagePath}" -C -b --color-bg --width 150 --complex\`).toString();
} catch (error) {
    dynamicImage = chalk.red('\\n[!] فشل تحويل الصورة، تأكد من تثبيت الأداة وصلاحية الوصول.\\n');
}

export const asciiArt = \`
\${chalk.hex('#FF6BFF')('░▒▓██████▓▒░░▒▓███████▓▒░ ░▒▓██████▓▒░ ░▒▓███████▓▒░▒▓████████▓▒░▒▓██████▓▒░ ░▒▓███████▓▒░▒▓█▓▒░░▒▓██████▓▒░')}
\${chalk.hex('#E45CFF')('░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░         ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░')}
\${chalk.hex('#C84DFF')('░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░         ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░')}
\${chalk.hex('#B03CFF')('░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░░▒▓██████▓▒░   ░▒▓█▓▒░  ░▒▓████████▓▒░░▒▓██████▓▒░░▒▓█▓▒░▒▓████████▓▒░')}
\${chalk.hex('#9A2FFF')('░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░  ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░')}
\${chalk.hex('#FF7CFF')('░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░  ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░')}
\${chalk.hex('#FF6BFF')('░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░   ░▒▓█▓▒░  ░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░')}
\${chalk.hex('#FF7CFF')('\\n           ✦彡  ANASTASIA ULTRA NOVA VER 彡✦\\n')}

\${dynamicImage}
\`;
`;

      fs.writeFileSync(path.join(newFolderPath, "art.js"), codeContent.trim());

      // 6. إرسال تأكيد
      await sock.sendMessage(remoteJid, {
        text: `✅ *تم إنشاء الثيم بنجاح!*\n\n📂 المجلد: ${nextFolderNum}\n🖼️ الصورة: ${themeImageName}\n📄 الملف: art.js\n📍 المسار: ${newFolderPath}`
      }, { quoted: msg });

    } catch (error) {
      console.error(error);
      await sock.sendMessage(remoteJid, { text: "❌ فشل في معالجة الثيم أو الوصول للذاكرة." }, { quoted: msg });
    }
  }
};