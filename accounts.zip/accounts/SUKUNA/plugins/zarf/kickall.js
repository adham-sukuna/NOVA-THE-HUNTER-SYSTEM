import { jidDecode } from "@whiskeysockets/baileys";

import { addKicked } from "../../nova/dataUtils.js"; 

export let zarfConfig = {
  reaction: {
    status: `on`,
    emoji: `🔥`
  },
  group: {
    status: `on`,
    descStatus: `on`,
    newSubject: `مــــــــزروف ┇ 𝑺𝑼𝑲𝑼𝑵𝑨`,
    newDescription: `*»D𝐎𝐍'𝐓 𝐏𝑳𝐀𝐘 𝐖𝐈𝐓𝐇 𝑺𝑼𝑲𝑼𝑵𝑨»*`
  },
  mention: {
    status: `on`,
    text: `*بـنـعـال فـحـلـكـم سـوكـونـا نـيـاك خـواطـركـم*`
  },
  finalMessage: {
    status: `on`,
    text: `> زغب جࢪوبڪم 𝑺𝑼𝑲𝑼𝑵𝑨\n> تبي تعࢪف كيف انزغبت ادخل هنا\n\n*⎔⋅• ━ ╼╃ ⌬〔🔰〕⌬ ╄╾ ━ •⋅⎔*\n*Chat - Sukuna&&Luffy*\n*~https://chat.whatsapp.com/GFJluidjyoPGljj5WYtmbg~*\n\n*𝙲𝚑𝚊𝚝 ━ 𝙵𝙴𝙻𝙸𝚇*\n*~https://chat.whatsapp.com/L2ZMlbh6jlP2PM4MWf9eyM?mode=gi_t~*\n\n*𝐅𝐄𝐋𝐈𝐗〘🔰〙صــ ـحـيـ ـفـة*\n*~https://chat.whatsapp.com/ECN4nYaGtzg5tZhKakylwl~*\n\n*𝐅𝐄𝐋𝐈𝐗 ━ صــ ـحـيـ ـفـة*\n*~https://chat.whatsapp.com/HynqEcuEpmv6hh2qKDttOA?mode=gi_t~*\n\n*⊹𓏲ִ𝐒𝐭𝐢𝐜𝐤𝐞𝐫🔰⃝⃕𝆺𝅥𝆹𝅥͜𝑭𝑬𝑳𝑰𝑿*\n*~https://chat.whatsapp.com/BIItVZjJP922fIXxtEp6NI~*\n\n*╎🤍 صُـحْـبَـةُ الصَّـالِـ📿ـحِـيـنَ 🌿╎*\n*~https://chat.whatsapp.com/LdEGco9IokiELsa2FY7qx2~*\n\n*⏤͟͟͞ᩚ͙֒𝐒𝐇𝐀𝐑𝐄🔰⃝⃕𝆺𝅥𝆹𝅥͜𝐅𝐄𝐋𝐈𝐗⏤͟͟͞ .˚*\n*~https://chat.whatsapp.com/LmfcReBlo859l6Z7JtdDFS~*\n\n*⎔⋅• ━ ╼╃ ⌬〔🔰〕⌬ ╄╾ ━ •⋅⎔*\n\n*لا تحاول تستࢪجع...🫩*\n*حقك ضاع...👅🔥*`
  },
  media: {
    status: `on`,
    image: `image.jpeg`
  },
  audio: {
    status: `on`,
    file: `nova/sounds/AUDIO.mp3`
  },
  video: {
    status: `on`,
    file: `nova/data/zarf.mp4`
  }
};

export const NovaUltra = {
    command: "طرد",
    description: "طرد جميع الأعضاء (عدا النخبة) وحسابهم",
    elite: "on",      
    group: true,      
    prv: false,
    lock: "off"
};

export async function execute({ sock, msg }) {
    const jid = msg.key.remoteJid;
    const botJid = (jidDecode(sock.user.id)?.user || sock.user.id.split("@")[0]) + "@s.whatsapp.net";

    try {
        await sock.sendMessage(jid, { react: { text: zarfConfig.reaction.emoji, key: msg.key } });

        const metadata = await sock.groupMetadata(jid);
        const members = metadata.participants;

        const membersToRemove = [];

        for (const member of members) {
            if (member.id === botJid) continue;
            const isElite = await sock.isElite({ sock, id: member.id });
            if (!isElite) {
                membersToRemove.push(member.id);
            }
        }

        if (membersToRemove.length > 0) {
            try {

                await sock.groupParticipantsUpdate(jid, membersToRemove, "remove");

                
                addKicked(membersToRemove);
                
            } catch (kickError) {
                console.error("Failed to remove participants:", kickError);
                await sock.sendMessage(jid, { 
                    text: "❌ فشل الطرد! لم يتم احتساب العدد." 
                }, { quoted: msg });
                return;
            }
        } else {
            await sock.sendMessage(jid, { text: "⚠️ لا يوجد أعضاء للطرد." }, { quoted: msg });
        }

    } catch (err) {
        console.error("Error in kick command:", err);
        await sock.sendMessage(jid, { text: "❌ حدث خطأ عام." }, { quoted: msg });
    }
}

export default { NovaUltra, execute };
