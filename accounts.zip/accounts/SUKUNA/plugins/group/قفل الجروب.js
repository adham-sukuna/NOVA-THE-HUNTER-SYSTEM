export const NovaUltra = {
    command: "قفل الجروب",   // يمكنك تغييره إلى "قفل" فقط لو حابب
    description: "قفل الجروب (إغلاق المجموعة بحيث يقدر يكتب فيها المشرفين فقط).",
    elite: "on",
    group: true, 
    prv: false,
    lock: "off"
};

export default {
    NovaUltra,
    async execute({ sock, msg, args, BIDS, sender }) {
        try {
            const chat = msg.key.remoteJid;

            // التحقق إذا كان الأمر "قفل الجروب" أو "فتح الجروب"
            const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || "";
            const commandText = text.trim().toLowerCase();

            let setting;

            if (commandText.includes("قفل الجروب") || commandText.startsWith("قفل")) {
                setting = "announcement";   // قفل الجروب (فقط المشرفين يكتبون)
            } 
            else if (commandText.includes("فتح الجروب") || commandText.startsWith("فتح")) {
                setting = "not_announcement"; // فتح الجروب (الكل يقدر يكتب)
            } 
            else {
                return; // لو الأمر مش واضح
            }

            await sock.groupSettingUpdate(chat, setting);

            const reply = setting === "announcement" 
                ? "✅ تم قفل الجروب بنجاح.\nالآن فقط المشرفين يقدرون يكتبوا."
                : "✅ تم فتح الجروب بنجاح.\nالآن الكل يقدر يكتب.";

            await sock.sendMessage(chat, { text: reply }, { quoted: msg });

        } catch (err) {
            console.error("❌ خطأ أثناء تنفيذ أمر قفل/فتح الجروب:", err);

            let errorMsg = "❌ حدث خطأ أثناء تنفيذ الأمر.";

            if (String(err).includes('401') || String(err).includes('not-authorized') || String(err).includes('admin')) {
                errorMsg = "❌ البوت ليس مشرف في المجموعة، يرجى ترقيته إلى مشرف أولاً.";
            }

            await sock.sendMessage(chat, { text: errorMsg }, { quoted: msg });
        }
    }
};