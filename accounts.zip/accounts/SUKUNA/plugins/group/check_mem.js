import { jidDecode } from '@whiskeysockets/baileys'

const NovaUltra = {
  command: 'checkmem',
  description: 'Scan group members for multi-device usage',
  elite: true,
  group: true,
  prv: false,
  lock: false
}

const BATCH_SIZE = 20
const BATCH_DELAY = 700
const PAGE_SIZE = 30
const PROGRESS_EVERY = 3

const sleep = ms => new Promise(r => setTimeout(r, ms))
const userOf = jid => jidDecode(jid)?.user || String(jid).split('@')[0]
const chunk = (arr, n) => {
  const out = []
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n))
  return out
}
const bar = (done, total, len = 12) => {
  const f = total ? Math.round((done / total) * len) : 0
  return '█'.repeat(f) + '░'.repeat(len - f)
}
const fmtTime = ms => {
  const s = Math.round(ms / 1000)
  return s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`
}

// per-group scan state
const running = new Map()

function getArgs(msg, args) {
  if (Array.isArray(args) && args.length) return args.map(String)
  const text = msg.message?.conversation
    || msg.message?.extendedTextMessage?.text
    || msg.message?.imageMessage?.caption || ''
  return text
    .replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069]/g, '')
    .trim().split(/\s+/).slice(1)
}

async function fetchDevices(sock, jids) {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await sock.getUSyncDevices(jids, false, false)
    } catch (e) {
      if (attempt === 1) throw e
      await sleep(1500)
    }
  }
}

async function scanDevices({ sock, jid, members, minDevices, onProgress }) {
  const state = running.get(jid)
  const batches = chunk(members, BATCH_SIZE)
  const multi = []
  let scanned = 0
  let failed = 0

  for (let i = 0; i < batches.length; i++) {
    if (state.stop) break
    const batch = batches[i]

    try {
      const devices = await fetchDevices(sock, batch.map(p => p.id))
      const counts = {}
      for (const d of devices) counts[d.user] = (counts[d.user] || 0) + 1

      for (const p of batch) {
        const user = userOf(p.id)
        const count = counts[user] || 0
        if (count >= minDevices) {
          multi.push({
            jid: p.id,
            user,
            count,
            admin: !!p.admin,
            phone: p.phoneNumber ? userOf(p.phoneNumber) : null
          })
        }
      }
    } catch (e) {
      console.error('[checkmem] batch failed:', e.message)
      failed += batch.length
    }

    scanned += batch.length
    if ((i + 1) % PROGRESS_EVERY === 0 && i + 1 < batches.length) {
      await onProgress?.(scanned, members.length).catch(() => {})
    }
    await sleep(BATCH_DELAY)
  }

  multi.sort((a, b) => b.count - a.count)
  return { multi, scanned, failed, stopped: state.stop }
}

async function sendResult({ sock, jid, msg, result, minDevices, total, elapsed }) {
  const { multi, scanned, failed, stopped } = result
  const top = multi[0]?.count || 0

  const header =
    `📊 *SCAN RESULTS • GROUP MEMBERS*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    (stopped ? `🛑 Stopped early\n` : '') +
    `👥 Scanned: *${scanned}/${total}*\n` +
    `📱 Min devices: *${minDevices}*\n` +
    `🎯 Matches: *${multi.length}*` + (top ? ` (max ${top} devices)` : '') + `\n` +
    (failed ? `⚠️ Failed to check: *${failed}*\n` : '') +
    `⏱️ Time: *${fmtTime(elapsed)}*\n\n`

  if (!multi.length) {
    await sock.sendMessage(jid, { text: header + `✅ No accounts found with ${minDevices}+ devices.` }, { quoted: msg })
    return sock.sendMessage(jid, { react: { text: '✅', key: msg.key } }).catch(() => {})
  }

  const pages = chunk(multi, PAGE_SIZE)
  let index = 1

  for (let p = 0; p < pages.length; p++) {
    let text = p === 0 ? header : `📄 *Page ${p + 1}/${pages.length}*\n\n`

    for (const item of pages[p]) {
      text += `*${index}.* @${item.user}${item.admin ? ' 👑' : ''}\n`
      text += `   📱 Devices: *${item.count}*`
      if (item.phone) text += ` • 📞 ${item.phone}`
      text += `\n\n`
      index++
    }

    await sock.sendMessage(jid, { text, mentions: pages[p].map(i => i.jid) }, { quoted: msg })
    await sleep(500)
  }

  await sock.sendMessage(jid, { react: { text: '✅', key: msg.key } }).catch(() => {})
}

async function execute({ sock, msg, args }) {
  const jid = msg.key.remoteJid
  const reply = text => sock.sendMessage(jid, { text }, { quoted: msg })
  const react = text => sock.sendMessage(jid, { react: { text, key: msg.key } }).catch(() => {})

  try {
    if (!jid.endsWith('@g.us')) return reply('⚠️ This command works in groups only.')

    const words = getArgs(msg, args)
    const first = words[0]?.toLowerCase()

    // stop
    if (first === 'stop' || first === 'ايقاف') {
      const st = running.get(jid)
      if (st) {
        st.stop = true
        return reply('🛑 Stopping the scan...')
      }
      return reply('⚠️ No active scan in this group.')
    }

    if (running.has(jid)) {
      return reply('⚠️ A scan is already running. Send `checkmem stop` to cancel it.')
    }

    const meta = await sock.groupMetadata(jid)
    const sender = msg.key.participant || jid
    const me = meta.participants.find(
      p => p.id === sender || p.lid === sender || userOf(p.id) === userOf(sender)
    )
    if (!me?.admin && !msg.key.fromMe) return reply('❌ Admins only.')

    const minDevices = Math.max(2, parseInt(first) || 2)

    const botIds = new Set(
      [sock.user?.id, sock.user?.lid].filter(Boolean).map(userOf)
    )
    const members = meta.participants.filter(p => {
      const ids = [p.id, p.lid].filter(Boolean).map(userOf)
      return !ids.some(id => botIds.has(id))
    })

    if (!members.length) return reply('⚠️ No members to scan.')

    await react('🍁')
    const loading = await reply(
      `🔄 *Scanning members...*\n${bar(0, members.length)} 0%\n👥 0/${members.length}`
    )

    running.set(jid, { stop: false })
    const startedAt = Date.now()

    const onProgress = (done, total) =>
      sock.sendMessage(jid, {
        text: `🔄 *Scanning members...*\n${bar(done, total)} ${Math.round((done / total) * 100)}%\n👥 ${done}/${total} • ⏱️ ${fmtTime(Date.now() - startedAt)}`,
        edit: loading.key
      })

    let result
    try {
      result = await scanDevices({ sock, jid, members, minDevices, onProgress })
    } finally {
      running.delete(jid)
    }

    await sock.sendMessage(jid, { delete: loading.key }).catch(() => {})
    return sendResult({
      sock, jid, msg, result, minDevices,
      total: members.length,
      elapsed: Date.now() - startedAt
    })
  } catch (err) {
    console.error('[checkmem] failed:', err)
    running.delete(jid)
    await react('❌')
    return reply(`❌ Error: ${err.message || 'Unknown error'}`)
  }
}

export default { NovaUltra, execute }
